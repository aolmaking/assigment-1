require("dotenv").config();

const connectDatabase = require("./config/database");
const { createApp } = require("./app");

async function startServer() {
  const requiredSettings = [
    "MONGODB_URI",
    "ACCESS_TOKEN_SECRET",
    "REFRESH_TOKEN_SECRET",
    "OTP_SECRET",
    "SMTP_HOST",
    "SMTP_PORT",
    "SMTP_USER",
    "SMTP_PASS"
  ];
  const missingSettings = requiredSettings.filter((setting) => !process.env[setting]);

  if (missingSettings.length > 0) {
    throw new Error(`Missing environment settings: ${missingSettings.join(", ")}`);
  }

  await connectDatabase();

  const port = Number(process.env.PORT || 3000);
  const app = createApp();

  app.listen(port, () => {
    process.stdout.write(`Server is running on port ${port}\n`);
  });
}

startServer().catch((error) => {
  process.stderr.write(`${error.message}\n`);
  process.exit(1);
});
