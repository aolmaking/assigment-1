const express = require("express");
const helmet = require("helmet");
const createAuthRoutes = require("./routes/authRoutes");
const { sendOtpEmail } = require("./services/emailService");
const { notFoundHandler, errorHandler } = require("./middleware/errorMiddleware");

function createApp(options = {}) {
  const app = express();
  const emailSender = options.sendOtpEmail || sendOtpEmail;

  app.use(helmet());
  app.use(express.json({ limit: "10kb" }));
  app.use("/api/auth", createAuthRoutes({ sendOtpEmail: emailSender }));
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = { createApp };
