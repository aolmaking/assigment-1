const crypto = require("node:crypto");

function createOtp() {
  return crypto.randomInt(0, 1000000).toString().padStart(6, "0");
}

function hashOtp(otp) {
  const secret = process.env.OTP_SECRET;

  if (!secret) {
    throw new Error("OTP_SECRET is missing");
  }

  return crypto.createHmac("sha256", secret).update(otp).digest("hex");
}

function compareOtp(otp, savedHash) {
  const currentHash = Buffer.from(hashOtp(otp), "hex");
  const storedHash = Buffer.from(savedHash, "hex");

  return currentHash.length === storedHash.length && crypto.timingSafeEqual(currentHash, storedHash);
}

module.exports = { createOtp, hashOtp, compareOtp };
