function notFoundHandler(req, res) {
  return res.status(404).json({ message: "Route not found" });
}

function errorHandler(error, req, res, next) {
  if (res.headersSent) {
    return next(error);
  }

  if (error.code === 11000) {
    return res.status(409).json({ message: "An account with this email already exists" });
  }

  if (error.name === "ValidationError" || error.name === "CastError") {
    return res.status(400).json({ message: "Invalid request data" });
  }

  const statusCode = Number(error.statusCode || error.status) || 500;
  const message = statusCode >= 500 ? "Something went wrong" : error.message;

  return res.status(statusCode).json({ message });
}

module.exports = { notFoundHandler, errorHandler };
