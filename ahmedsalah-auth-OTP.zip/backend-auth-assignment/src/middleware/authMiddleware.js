const jwt = require("jsonwebtoken");
const User = require("../models/User");

async function requireLogin(req, res, next) {
  try {
    const authorization = req.headers.authorization;
    const [scheme, token] = authorization ? authorization.split(" ") : [];

    if (scheme !== "Bearer" || !token) {
      return res.status(401).json({ message: "Authentication is required" });
    }

    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);

    if (decoded.type !== "access") {
      return res.status(401).json({ message: "Invalid access token" });
    }

    const user = await User.findById(decoded.sub);

    if (!user) {
      return res.status(401).json({ message: "Invalid access token" });
    }

    req.user = user;
    return next();
  } catch (error) {
    return res.status(401).json({ message: "Invalid or expired access token" });
  }
}

module.exports = { requireLogin };
