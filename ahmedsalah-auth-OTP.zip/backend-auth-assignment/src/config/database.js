const mongoose = require("mongoose");

async function connectDatabase() {
  const databaseUrl = process.env.MONGODB_URI;

  if (!databaseUrl) {
    throw new Error("MONGODB_URI is missing");
  }

  await mongoose.connect(databaseUrl);
}

module.exports = connectDatabase;
