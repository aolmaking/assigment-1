const mongoose = require("mongoose");

const otpChallengeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },
    purpose: {
      type: String,
      required: true,
      enum: ["enable_2fa", "login"],
      index: true
    },
    codeHash: {
      type: String,
      required: true,
      select: false
    },
    expiresAt: {
      type: Date,
      required: true,
      index: { expires: 0 }
    },
    attempts: {
      type: Number,
      default: 0,
      min: 0
    },
    consumedAt: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true,
    versionKey: false
  }
);

module.exports = mongoose.model("OtpChallenge", otpChallengeSchema);
