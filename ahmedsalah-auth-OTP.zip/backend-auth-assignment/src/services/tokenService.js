const jwt = require("jsonwebtoken");

function createTokens(userId) {
  const accessSecret = process.env.ACCESS_TOKEN_SECRET;
  const refreshSecret = process.env.REFRESH_TOKEN_SECRET;

  if (!accessSecret || !refreshSecret) {
    throw new Error("Token secrets are missing");
  }

  const accessToken = jwt.sign(
    { sub: userId.toString(), type: "access" },
    accessSecret,
    { expiresIn: process.env.ACCESS_TOKEN_TTL || "15m" }
  );

  const refreshToken = jwt.sign(
    { sub: userId.toString(), type: "refresh" },
    refreshSecret,
    { expiresIn: process.env.REFRESH_TOKEN_TTL || "7d" }
  );

  return {
    accessToken,
    refreshToken,
    tokenType: "Bearer",
    expiresIn: Number(process.env.ACCESS_TOKEN_TTL_SECONDS || 900)
  };
}

module.exports = { createTokens };
