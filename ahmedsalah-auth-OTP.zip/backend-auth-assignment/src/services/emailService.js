const nodemailer = require("nodemailer");

let mailTransporter;

function getMailTransporter() {
  if (mailTransporter) {
    return mailTransporter;
  }

  const { SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS } = process.env;

  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
    throw new Error("Email service is not configured");
  }

  mailTransporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: SMTP_SECURE === "true",
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS
    }
  });

  return mailTransporter;
}

async function sendOtpEmail(email, otp, purpose) {
  const transporter = getMailTransporter();
  const isLogin = purpose === "login";
  const subject = isLogin ? "Your login verification code" : "Enable two-step verification";
  const actionText = isLogin ? "complete your login" : "enable two-step verification";

  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: email,
    subject,
    text: `Your verification code is ${otp}. Use this code to ${actionText}. It expires in 10 minutes.`,
    html: `<p>Your verification code is:</p><h2>${otp}</h2><p>Use this code to ${actionText}. It expires in 10 minutes.</p>`
  });
}

module.exports = { sendOtpEmail };
