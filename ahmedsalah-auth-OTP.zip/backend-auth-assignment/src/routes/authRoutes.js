const express = require("express");
const { createAuthController } = require("../controllers/authController");
const { requireLogin } = require("../middleware/authMiddleware");

function createAuthRoutes(options) {
  const router = express.Router();
  const controller = createAuthController(options);

  router.post("/register", controller.register);
  router.post("/login", controller.login);
  router.post("/login/verify", controller.verifyLogin);
  router.post("/2fa/enable", requireLogin, controller.enableTwoFactor);
  router.post("/2fa/enable/verify", requireLogin, controller.verifyEnableTwoFactor);

  return router;
}

module.exports = createAuthRoutes;
