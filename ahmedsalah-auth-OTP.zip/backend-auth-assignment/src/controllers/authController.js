const mongoose = require("mongoose");
const User = require("../models/User");
const OtpChallenge = require("../models/OtpChallenge");
const { createOtp, hashOtp, compareOtp } = require("../utils/otp");
const { createTokens } = require("../services/tokenService");

const LOGIN_LIMIT = 5;
const LOGIN_LOCK_TIME = 5 * 60 * 1000;
const OTP_LIFETIME = 10 * 60 * 1000;
const OTP_ATTEMPT_LIMIT = 5;

function sendLockedResponse(res, lockUntil) {
  const retryAfterSeconds = Math.max(1, Math.ceil((lockUntil.getTime() - Date.now()) / 1000));

  return res.status(423).json({
    message: "Account is temporarily locked",
    retryAfterSeconds
  });
}

async function issueOtp(user, purpose, sendOtpEmail) {
  const otp = createOtp();
  const now = new Date();

  await OtpChallenge.updateMany(
    { user: user._id, purpose, consumedAt: null },
    { $set: { consumedAt: now } }
  );

  const challenge = await OtpChallenge.create({
    user: user._id,
    purpose,
    codeHash: hashOtp(otp),
    expiresAt: new Date(now.getTime() + OTP_LIFETIME)
  });

  try {
    await sendOtpEmail(user.email, otp, purpose);
  } catch (error) {
    await OtpChallenge.updateOne(
      { _id: challenge._id, consumedAt: null },
      { $set: { consumedAt: new Date() } }
    );

    const mailError = new Error("Verification email could not be sent");
    mailError.statusCode = 503;
    throw mailError;
  }

  return challenge;
}

async function consumeOtp(challengeId, userId, purpose, otp) {
  if (!mongoose.isValidObjectId(challengeId) || typeof otp !== "string" || !/^\d{6}$/.test(otp)) {
    return { valid: false };
  }

  const now = new Date();
  const challengeFilter = {
    _id: challengeId,
    ...(userId ? { user: userId } : {}),
    purpose,
    expiresAt: { $gt: now },
    consumedAt: null,
    attempts: { $lt: OTP_ATTEMPT_LIMIT }
  };

  const challenge = await OtpChallenge.findOne(challengeFilter).select("+codeHash");

  if (!challenge) {
    return { valid: false };
  }

  if (!compareOtp(otp, challenge.codeHash)) {
    await OtpChallenge.updateOne(challengeFilter, { $inc: { attempts: 1 } });
    return { valid: false };
  }

  const consumedChallenge = await OtpChallenge.findOneAndUpdate(
    { ...challengeFilter, codeHash: challenge.codeHash },
    { $set: { consumedAt: now } },
    { new: true }
  );

  if (!consumedChallenge) {
    return { valid: false };
  }

  return { valid: true, challenge: consumedChallenge };
}

function createAuthController({ sendOtpEmail }) {
  async function register(req, res, next) {
    try {
      const { name, email, password } = req.body;

      if (
        typeof name !== "string" ||
        name.trim().length < 2 ||
        typeof email !== "string" ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ||
        typeof password !== "string" ||
        password.length < 8 ||
        Buffer.byteLength(password, "utf8") > 72
      ) {
        return res.status(400).json({
          message: "Name, valid email, and a password between 8 and 72 UTF-8 bytes are required"
        });
      }

      const user = await User.create({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        password
      });

      return res.status(201).json({
        message: "Account created successfully",
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          twoFactorEnabled: user.twoFactorEnabled
        }
      });
    } catch (error) {
      return next(error);
    }
  }

  async function login(req, res, next) {
    try {
      const { email, password } = req.body;

      if (typeof email !== "string" || typeof password !== "string" || !email.trim()) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await User.findOne({ email: email.trim().toLowerCase() }).select("+password");

      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const now = new Date();

      if (user.lockUntil && user.lockUntil > now) {
        return sendLockedResponse(res, user.lockUntil);
      }

      if (user.lockUntil && user.lockUntil <= now) {
        await User.updateOne(
          { _id: user._id, lockUntil: { $lte: now } },
          { $set: { failedLoginAttempts: 0, lockUntil: null } }
        );
        user.failedLoginAttempts = 0;
        user.lockUntil = null;
      }

      const passwordIsCorrect = await user.comparePassword(password);

      if (!passwordIsCorrect) {
        const lockUntil = new Date(Date.now() + LOGIN_LOCK_TIME);
        const updatedUser = await User.findOneAndUpdate(
          {
            _id: user._id,
            $or: [
              { lockUntil: { $exists: false } },
              { lockUntil: null },
              { lockUntil: { $lte: new Date() } }
            ]
          },
          [
            {
              $set: {
                failedLoginAttempts: {
                  $add: [{ $ifNull: ["$failedLoginAttempts", 0] }, 1]
                }
              }
            },
            {
              $set: {
                lockUntil: {
                  $cond: [
                    { $gte: ["$failedLoginAttempts", LOGIN_LIMIT] },
                    lockUntil,
                    null
                  ]
                }
              }
            }
          ],
          { new: true }
        );

        if (!updatedUser) {
          const currentUser = await User.findById(user._id);

          if (currentUser && currentUser.lockUntil && currentUser.lockUntil > new Date()) {
            return sendLockedResponse(res, currentUser.lockUntil);
          }

          return res.status(401).json({ message: "Invalid email or password" });
        }

        if (updatedUser.failedLoginAttempts >= LOGIN_LIMIT && updatedUser.lockUntil) {
          return sendLockedResponse(res, updatedUser.lockUntil);
        }

        return res.status(401).json({ message: "Invalid email or password" });
      }

      const resetResult = await User.updateOne(
        {
          _id: user._id,
          $or: [
            { lockUntil: { $exists: false } },
            { lockUntil: null },
            { lockUntil: { $lte: new Date() } }
          ]
        },
        { $set: { failedLoginAttempts: 0, lockUntil: null } }
      );

      if (resetResult.matchedCount === 0) {
        const currentUser = await User.findById(user._id);

        if (currentUser && currentUser.lockUntil && currentUser.lockUntil > new Date()) {
          return sendLockedResponse(res, currentUser.lockUntil);
        }

        return res.status(401).json({ message: "Invalid email or password" });
      }

      if (user.twoFactorEnabled) {
        const challenge = await issueOtp(user, "login", sendOtpEmail);

        return res.status(200).json({
          message: "A verification code has been sent to your email",
          requiresTwoFactor: true,
          challengeId: challenge._id,
          expiresIn: OTP_LIFETIME / 1000
        });
      }

      return res.status(200).json({
        message: "Login successful",
        requiresTwoFactor: false,
        ...createTokens(user._id)
      });
    } catch (error) {
      return next(error);
    }
  }

  async function enableTwoFactor(req, res, next) {
    try {
      if (req.user.twoFactorEnabled) {
        return res.status(409).json({ message: "Two-step verification is already enabled" });
      }

      const challenge = await issueOtp(req.user, "enable_2fa", sendOtpEmail);

      return res.status(200).json({
        message: "A verification code has been sent to your email",
        challengeId: challenge._id,
        expiresIn: OTP_LIFETIME / 1000
      });
    } catch (error) {
      return next(error);
    }
  }

  async function verifyEnableTwoFactor(req, res, next) {
    try {
      const { challengeId, otp } = req.body;
      const result = await consumeOtp(challengeId, req.user._id, "enable_2fa", otp);

      if (!result.valid) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }

      await User.updateOne(
        { _id: req.user._id, twoFactorEnabled: false },
        { $set: { twoFactorEnabled: true } }
      );

      return res.status(200).json({
        message: "Two-step verification has been enabled",
        twoFactorEnabled: true
      });
    } catch (error) {
      return next(error);
    }
  }

  async function verifyLogin(req, res, next) {
    try {
      const { challengeId, otp } = req.body;
      const result = await consumeOtp(challengeId, null, "login", otp);

      if (!result.valid) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }

      const user = await User.findById(result.challenge.user);

      if (!user || !user.twoFactorEnabled) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }

      if (user.lockUntil && user.lockUntil > new Date()) {
        return sendLockedResponse(res, user.lockUntil);
      }

      return res.status(200).json({
        message: "Login successful",
        ...createTokens(user._id)
      });
    } catch (error) {
      return next(error);
    }
  }

  return { register, login, enableTwoFactor, verifyEnableTwoFactor, verifyLogin };
}

module.exports = { createAuthController };
