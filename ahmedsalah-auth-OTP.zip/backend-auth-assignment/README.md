# Backend Authentication Assignment

A Node.js, Express, and MongoDB implementation of temporary account lockout and email-based two-step verification.

## Requirements

- Node.js 20 or newer
- MongoDB 4.2 or newer
- An SMTP account for sending verification emails

## Setup

1. Install the dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env`.

3. Set `MONGODB_URI` to your MongoDB connection string.

4. Replace the three token and OTP secrets with different random values. They must not be the same value.

5. Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `MAIL_FROM` to your email provider's SMTP settings.

6. Start the application:

   ```bash
   npm run dev
   ```

The API runs on `http://localhost:3000` by default.

## API

All request and response bodies use JSON.

### 1. Register a test account

`POST /api/auth/register`

```json
{
  "name": "Test User",
  "email": "test@example.com",
  "password": "StrongPass123"
}
```

The registration endpoint is included to make this project runnable on its own. Passwords are hashed before they are stored.

### 2. Login

`POST /api/auth/login`

```json
{
  "email": "test@example.com",
  "password": "StrongPass123"
}
```

When two-step verification is disabled, the response contains `accessToken` and `refreshToken`.

When two-step verification is enabled, the response contains `requiresTwoFactor: true` and a `challengeId`. It does not contain authentication tokens. The verification code is sent to the account email.

After five consecutive incorrect passwords, the account is locked for five minutes. A correct password resets the failed-attempt counter. Once the lock period expires, the next login attempt can proceed and the counter starts again.

A locked login request returns HTTP `423` and a `retryAfterSeconds` value.

### 3. Request two-step verification

This endpoint requires a valid access token.

`POST /api/auth/2fa/enable`

Header:

```text
Authorization: Bearer <accessToken>
```

The response contains a `challengeId`. A six-digit code is sent to the account email.

### 4. Confirm two-step verification

This endpoint also requires a valid access token.

`POST /api/auth/2fa/enable/verify`

```json
{
  "challengeId": "THE_CHALLENGE_ID",
  "otp": "123456"
}
```

Two-step verification is enabled only after the code is validated.

### 5. Complete a two-step login

`POST /api/auth/login/verify`

```json
{
  "challengeId": "THE_CHALLENGE_ID",
  "otp": "123456"
}
```

A successful response contains the access and refresh tokens.

## Verification behavior

- Login lockout is stored in MongoDB, so restarting the server does not clear it.
- Failed password attempts are updated with an atomic MongoDB update.
- A successful password login resets the consecutive failed-attempt counter.
- The five-minute lock is enforced by the API, not by a client-side timer.
- OTP values are generated with a cryptographically secure random generator.
- Only an HMAC hash of each OTP is stored in MongoDB.
- OTP challenges expire after ten minutes.
- Each challenge allows at most five incorrect verification attempts.
- A challenge is bound to its purpose and user.
- A new challenge invalidates the previous unconsumed challenge for the same user and purpose.
- A successfully verified challenge is consumed and cannot be reused.
- Access tokens are issued only after the second login step succeeds when two-step verification is enabled.

## Tests

Run the test suite with:

```bash
npm test
```

The tests use `mongodb-memory-server` and a test email sender, so they do not require a running MongoDB instance or a real SMTP account.
