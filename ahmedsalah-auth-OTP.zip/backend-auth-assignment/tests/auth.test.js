process.env.NODE_ENV = "test";
process.env.ACCESS_TOKEN_SECRET = "test_access_secret_with_enough_length_123456";
process.env.REFRESH_TOKEN_SECRET = "test_refresh_secret_with_enough_length_123456";
process.env.OTP_SECRET = "test_otp_secret_with_enough_length_123456";

const { before, after, beforeEach, test } = require("node:test");
const assert = require("node:assert/strict");
const mongoose = require("mongoose");
const request = require("supertest");
const { MongoMemoryServer } = require("mongodb-memory-server");
const { createApp } = require("../src/app");
const User = require("../src/models/User");
const OtpChallenge = require("../src/models/OtpChallenge");

let mongoServer;
let app;
const sentCodes = new Map();

app = createApp({
  sendOtpEmail: async (email, otp, purpose) => {
    sentCodes.set(`${email}:${purpose}`, otp);
  }
});

async function createAccount(email = "test@example.com") {
  const response = await request(app)
    .post("/api/auth/register")
    .send({ name: "Test User", email, password: "StrongPass123" });

  assert.equal(response.status, 201);
  return response.body.user;
}

async function login(email = "test@example.com", password = "StrongPass123") {
  return request(app).post("/api/auth/login").send({ email, password });
}

before(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

after(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

beforeEach(async () => {
  await Promise.all([User.deleteMany({}), OtpChallenge.deleteMany({})]);
  sentCodes.clear();
});

test("locks the account after five consecutive incorrect passwords and allows login after the lock expires", async () => {
  await createAccount();

  for (let attempt = 1; attempt <= 4; attempt += 1) {
    const response = await login("test@example.com", "WrongPass123");
    assert.equal(response.status, 401);
  }

  const fifthAttempt = await login("test@example.com", "WrongPass123");
  assert.equal(fifthAttempt.status, 423);
  assert.ok(fifthAttempt.body.retryAfterSeconds > 0);

  const savedUser = await User.findOne({ email: "test@example.com" });
  assert.equal(savedUser.failedLoginAttempts, 5);
  assert.ok(savedUser.lockUntil instanceof Date);

  const blockedAttempt = await login();
  assert.equal(blockedAttempt.status, 423);

  await User.updateOne(
    { _id: savedUser._id },
    { $set: { lockUntil: new Date(Date.now() - 1000) } }
  );

  const allowedLogin = await login();
  assert.equal(allowedLogin.status, 200);
  assert.equal(allowedLogin.body.requiresTwoFactor, false);
  assert.ok(allowedLogin.body.accessToken);
  assert.ok(allowedLogin.body.refreshToken);

  const unlockedUser = await User.findById(savedUser._id);
  assert.equal(unlockedUser.failedLoginAttempts, 0);
  assert.equal(unlockedUser.lockUntil, null);
});

test("resets consecutive failures after a correct password", async () => {
  await createAccount();

  await login("test@example.com", "WrongPass123");
  await login("test@example.com", "WrongPass123");

  const response = await login();
  assert.equal(response.status, 200);

  const savedUser = await User.findOne({ email: "test@example.com" });
  assert.equal(savedUser.failedLoginAttempts, 0);
});

test("enables two-step verification and requires a fresh one-time code during login", async () => {
  const account = await createAccount();
  const firstLogin = await login();
  const accessToken = firstLogin.body.accessToken;

  const enableResponse = await request(app)
    .post("/api/auth/2fa/enable")
    .set("Authorization", `Bearer ${accessToken}`);

  assert.equal(enableResponse.status, 200);
  assert.ok(enableResponse.body.challengeId);

  const enableCode = sentCodes.get("test@example.com:enable_2fa");
  assert.match(enableCode, /^\d{6}$/);

  const enableVerifyResponse = await request(app)
    .post("/api/auth/2fa/enable/verify")
    .set("Authorization", `Bearer ${accessToken}`)
    .send({ challengeId: enableResponse.body.challengeId, otp: enableCode });

  assert.equal(enableVerifyResponse.status, 200);
  assert.equal(enableVerifyResponse.body.twoFactorEnabled, true);

  const savedUser = await User.findById(account.id);
  assert.equal(savedUser.twoFactorEnabled, true);

  const secondLogin = await login();
  assert.equal(secondLogin.status, 200);
  assert.equal(secondLogin.body.requiresTwoFactor, true);
  assert.ok(secondLogin.body.challengeId);
  assert.equal(secondLogin.body.accessToken, undefined);
  assert.equal(secondLogin.body.refreshToken, undefined);

  const loginCode = sentCodes.get("test@example.com:login");
  assert.match(loginCode, /^\d{6}$/);

  const wrongLoginCode = loginCode === "000000" ? "000001" : "000000";
  const wrongCodeResponse = await request(app)
    .post("/api/auth/login/verify")
    .send({ challengeId: secondLogin.body.challengeId, otp: wrongLoginCode });

  assert.equal(wrongCodeResponse.status, 400);

  const verifyResponse = await request(app)
    .post("/api/auth/login/verify")
    .send({ challengeId: secondLogin.body.challengeId, otp: loginCode });

  assert.equal(verifyResponse.status, 200);
  assert.ok(verifyResponse.body.accessToken);
  assert.ok(verifyResponse.body.refreshToken);

  const replayResponse = await request(app)
    .post("/api/auth/login/verify")
    .send({ challengeId: secondLogin.body.challengeId, otp: loginCode });

  assert.equal(replayResponse.status, 400);
});

test("does not enable two-step verification with an incorrect code", async () => {
  await createAccount();
  const firstLogin = await login();

  const enableResponse = await request(app)
    .post("/api/auth/2fa/enable")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`);

  const enableCode = sentCodes.get("test@example.com:enable_2fa");
  const wrongEnableCode = enableCode === "000000" ? "000001" : "000000";
  const verifyResponse = await request(app)
    .post("/api/auth/2fa/enable/verify")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`)
    .send({ challengeId: enableResponse.body.challengeId, otp: wrongEnableCode });

  assert.equal(verifyResponse.status, 400);

  const savedUser = await User.findOne({ email: "test@example.com" });
  assert.equal(savedUser.twoFactorEnabled, false);
});


test("rejects an expired verification code", async () => {
  await createAccount();
  const firstLogin = await login();

  const enableResponse = await request(app)
    .post("/api/auth/2fa/enable")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`);

  const enableCode = sentCodes.get("test@example.com:enable_2fa");
  await OtpChallenge.updateOne(
    { _id: enableResponse.body.challengeId },
    { $set: { expiresAt: new Date(Date.now() - 1000) } }
  );

  const verifyResponse = await request(app)
    .post("/api/auth/2fa/enable/verify")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`)
    .send({ challengeId: enableResponse.body.challengeId, otp: enableCode });

  assert.equal(verifyResponse.status, 400);
});


test("stops accepting codes after five incorrect OTP attempts", async () => {
  await createAccount();
  const firstLogin = await login();

  const enableResponse = await request(app)
    .post("/api/auth/2fa/enable")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`);

  const enableCode = sentCodes.get("test@example.com:enable_2fa");
  const wrongEnableCode = enableCode === "000000" ? "000001" : "000000";

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const response = await request(app)
      .post("/api/auth/2fa/enable/verify")
      .set("Authorization", `Bearer ${firstLogin.body.accessToken}`)
      .send({ challengeId: enableResponse.body.challengeId, otp: wrongEnableCode });

    assert.equal(response.status, 400);
  }

  const correctCodeResponse = await request(app)
    .post("/api/auth/2fa/enable/verify")
    .set("Authorization", `Bearer ${firstLogin.body.accessToken}`)
    .send({ challengeId: enableResponse.body.challengeId, otp: enableCode });

  assert.equal(correctCodeResponse.status, 400);

  const savedUser = await User.findOne({ email: "test@example.com" });
  assert.equal(savedUser.twoFactorEnabled, false);
});
